/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_wasmnoderouter_free: (a: number, b: number) => void;
export const wasmnoderouter_new: (a: any) => [number, number, number];
export const wasmnoderouter_setOption: (a: number, b: number, c: number, d: number, e: number) => [number, number];
export const wasmnoderouter_solveForTerminalPairs: (a: number, b: any) => [number, number, number];
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
